
/*
 * Corner Grocer - Item Frequency Tracker
 * Author: Josh Duthu
 * Date: 2025-10-15
 */

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <limits>
#include <cctype>

static std::string ToLower(const std::string& s) {
    std::string r; r.reserve(s.size());
    for (unsigned char ch : s) r.push_back(static_cast<char>(std::tolower(ch)));
    return r;
}

class FrequencyAnalyzer {
public:
    bool LoadFromFile(const std::string& fileName) {
        std::ifstream in(fileName);
        if (!in) return false;
        std::string word;
        while (in >> word) {
            ++m_freq[ToLower(word)];
        }
        return true;
    }

    bool WriteBackup(const std::string& outFile) const {
        std::ofstream out(outFile);
        if (!out) return false;
        for (const auto& kv : m_freq) {
            out << kv.first << ' ' << kv.second << '\n';
        }
        return true;
    }

    int GetCount(const std::string& item) const {
        auto it = m_freq.find(ToLower(item));
        return (it == m_freq.end()) ? 0 : it->second;
    }

    void PrintAll() const {
        for (const auto& kv : m_freq) {
            std::cout << kv.first << ' ' << kv.second << '\n';
        }
    }

    void PrintHistogram(char barChar='*') const {
        for (const auto& kv : m_freq) {
            std::cout << kv.first << ' ';
            for (int i = 0; i < kv.second; ++i) std::cout << barChar;
            std::cout << '\n';
        }
    }
private:
    std::map<std::string, int> m_freq;
};

static int ReadMenuChoice() {
    while (true) {
        std::cout << "\n===== Corner Grocer Menu =====\n"
                  << "1. Query item frequency\n"
                  << "2. Print all item frequencies\n"
                  << "3. Print histogram\n"
                  << "4. Exit\n"
                  << "Select an option (1-4): ";
        int choice;
        if (std::cin >> choice && choice >=1 && choice <=4) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return choice;
        }
        std::cout << "Invalid selection. Please enter 1-4.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    const std::string inputFile = "CS210_Project_Three_Input_File.txt";
    const std::string backupFile = "frequency.dat";

    FrequencyAnalyzer tracker;
    if (!tracker.LoadFromFile(inputFile)) {
        std::cerr << "Error: Could not open input file '" << inputFile << "'.\n";
        return 1;
    }
    tracker.WriteBackup(backupFile);

    while (true) {
        int choice = ReadMenuChoice();
        if (choice == 1) {
            std::cout << "Enter item to search: ";
            std::string item;
            std::getline(std::cin, item);
            std::cout << tracker.GetCount(item) << "\n";
        } else if (choice == 2) {
            tracker.PrintAll();
        } else if (choice == 3) {
            tracker.PrintHistogram('*');
        } else if (choice == 4) {
            std::cout << "Goodbye.\n";
            break;
        }
    }
    return 0;
}
